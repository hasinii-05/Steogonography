
export enum Mode {
    Encode = 'ENCODE',
    Decode = 'DECODE',
}
